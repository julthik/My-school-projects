<?php
//Объявление и определение констант
const DB_DATABASE = "moviesdb";
const DB_HOST = "localhost";
const DB_PORT = "3306";
const DB_USERNAME = "root";
const DB_PASSWORD="";
const DB_CHARSET="utf8";

